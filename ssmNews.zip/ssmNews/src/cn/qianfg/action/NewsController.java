package cn.qianfg.action;

import cn.qianfg.pojo.FenYe;
import cn.qianfg.pojo.News;
import cn.qianfg.pojo.NewsType;
import cn.qianfg.service.FileUploadNews;
import cn.qianfg.service.NewsService;
import cn.qianfg.service.NewsTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@RequestMapping("/news")
public class NewsController {
    @Autowired
    private NewsService ns;
    @Autowired
    private NewsTypeService nts;
    @Autowired
    private FileUploadNews fun;

    @RequestMapping("/newsMain")
    public ModelAndView newsMain(FenYe fy) {
        ModelAndView mv = new ModelAndView();
        //获取新闻菜单栏
        List<News> newsList = ns.queryNewsByFy(fy);
        mv.addObject("newsList", newsList);
        mv.setViewName("main");
        return mv;
    }

    @RequestMapping("/newsMainJson")
    @ResponseBody
    public List<News> newsMainJson(FenYe fy) {
        List<News> newsList = ns.queryNewsByFy(fy);
        return newsList;
    }

    @RequestMapping("/deleteNews")
    public ModelAndView deleteNews(int[] id) {
        ModelAndView mv = new ModelAndView();
        ns.deleteNews(id);
        mv.setViewName("redirect:newsMain");
        return mv;
    }

    @RequestMapping("/toAddNews")
    public ModelAndView toAddNews() {
        ModelAndView mv = new ModelAndView();
        List<NewsType> newsTypeList = nts.queryAllNewsType();
        mv.addObject("newsTypeList", newsTypeList);
        mv.setViewName("addNews");
        return mv;
    }

    @RequestMapping("/addNews")
    public ModelAndView addNews(News news, @RequestParam("picUrl") MultipartFile picUrl) {
        ModelAndView mv = new ModelAndView();
        news = fun.upload(news, picUrl);
        int flag = ns.addNews(news);
        if (flag > 0) {
            mv.setViewName("redirect:newsMain");
        } else {
            mv.addObject("error", "添加失败");
            mv.setViewName("redirect:toAddNews");
        }
        return mv;
    }

    @RequestMapping("/toUpdateNews")
    public ModelAndView toUpdateNews(int id) {
        ModelAndView mv = new ModelAndView();
        News news = ns.queryNewsById(id);
        List<NewsType> newsTypeList = nts.queryAllNewsType();
        mv.addObject("news", news);
        mv.addObject("newsTypeList", newsTypeList);
        mv.setViewName("updateNews");
        return mv;
    }

    @RequestMapping("/updateNews")
    public ModelAndView updateNews(News news, @RequestParam("picUrl") MultipartFile picUrl) {
        ModelAndView mv = new ModelAndView();
        news = fun.upload(news, picUrl);
        int flag = ns.updateNews(news);
        if (flag > 0) {
            mv.setViewName("redirect:newsMain");
        } else {
            mv.addObject("error", "修改失败");
            mv.setViewName("redirect:toUpdateNews");
        }
        return mv;
    }
}
