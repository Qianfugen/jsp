package cn.qianfg.action;

import cn.qianfg.pojo.User;
import cn.qianfg.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

@Controller
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService us;

    @RequestMapping("/login")
    public ModelAndView login(HttpServletResponse response, HttpSession session, User loginUser, String isno) {
        ModelAndView mv = new ModelAndView();
//        System.out.println("这里是/user/login");
//        System.out.println(loginUser);
        loginUser = us.login(loginUser);
        if (loginUser != null) {     //存在该用户,密码正确
            if ("yes".equals(isno)) {     //勾选了保存登录信息
                //创建cookie
                Cookie cName = null;
                try {
                    cName = new Cookie("cName", URLEncoder.encode(loginUser.getName(), "utf-8"));
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                Cookie cPwd = new Cookie("cPwd", loginUser.getPwd());
                //设置生命周期
                cName.setMaxAge(10 * 24 * 60 * 60);
                cPwd.setMaxAge(10 * 24 * 60 * 60);
                //设置保存路径
                cName.setPath("/ssmNews");
                cPwd.setPath("/ssmNews");
                //添加到response
                response.addCookie(cName);
                response.addCookie(cPwd);
            }
            //重定向
            mv.setViewName("redirect:/userMain.jsp");
        } else {
            mv.addObject("error", "用户名或密码错误");
            mv.setViewName("redirect:/login.jsp");
        }
        //要把user设置到session,不要通过注解
        session.setAttribute("user", loginUser);

        return mv;
    }

    @RequestMapping("/out")
    public ModelAndView out(HttpSession session) {
        ModelAndView mv = new ModelAndView();
        session.invalidate();
        mv.setViewName("redirect:/login.jsp");
        return mv;
    }

    @RequestMapping("/register")
    public ModelAndView register(User user) {
        ModelAndView mv = new ModelAndView();
        int flag = us.register(user);
        //要带参数返回error,使用redirect
        if (flag > 0) {
            mv.setViewName("login");
        } else {
            mv.addObject("error", "用户名或密码不规范");
            mv.setViewName("redirect:/regName.jsp");
        }
        return mv;
    }
}
