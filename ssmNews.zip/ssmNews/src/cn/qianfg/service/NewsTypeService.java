package cn.qianfg.service;

import cn.qianfg.pojo.NewsType;

import java.util.List;

public interface NewsTypeService {
    public List<NewsType> queryAllNewsType();
}
