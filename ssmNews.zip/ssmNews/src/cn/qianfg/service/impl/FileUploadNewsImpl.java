package cn.qianfg.service.impl;

import cn.qianfg.pojo.News;
import cn.qianfg.service.FileUploadNews;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

@Service
public class FileUploadNewsImpl implements FileUploadNews {
    @Override
    public News upload(News news, MultipartFile picUrl) {
        //获取旧名
        String oldName = picUrl.getOriginalFilename();
        if (oldName != null && !"".equals(oldName)) {
            //取新名
            String newName = UUID.randomUUID().toString() + oldName.substring(oldName.lastIndexOf("."));
            //写入文件
            File f = new File("C:/Users/root/Desktop/img/" + newName);
            try {
                picUrl.transferTo(f);
            } catch (IOException e) {
                e.printStackTrace();
            }
            news.setPic("../img/" + newName);
        }
        return news;
    }
}
