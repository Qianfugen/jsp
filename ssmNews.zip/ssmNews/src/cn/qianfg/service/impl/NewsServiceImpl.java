package cn.qianfg.service.impl;


import cn.qianfg.dao.NewsDao;
import cn.qianfg.pojo.FenYe;
import cn.qianfg.pojo.News;
import cn.qianfg.pojo.QueryNews;
import cn.qianfg.service.NewsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NewsServiceImpl implements NewsService {
    @Autowired
    private NewsDao nd;

    @Override
    public int addNews(News news) {
        int flag = nd.addNews(news);
        return flag;
    }

    @Override
    public int deleteNews(int[] id) {
        int flag = -1;
        for (int i : id) {
            flag = nd.deleteNews(i);
        }
        return flag;
    }

    @Override
    public int updateNews(News news) {
        int flag = nd.updateNews(news);
        return flag;
    }

    @Override
    public News queryNewsById(int id) {
        News news = nd.queryNewsById(id);
        return news;
    }

    @Override
    public List queryNewsByFy(FenYe fy) {
        fy.setRowsCount(nd.queryNewsCount(fy.getQueryNews()));

        Integer page = null;
        System.out.println("总页数:" + fy.getPageCount());
        //设置当前页码
        if (fy.getPage() != null) {
            if (fy.getPage() <= 0) {
                fy.setPage(1);
            }
            if (fy.getPage() > fy.getPageCount()) {
                fy.setPage(fy.getPageCount());
            }
        } else {
            fy.setPage(1);
        }
        List<News> newsList = nd.queryNewsByFy(fy);

        return newsList;
    }
}
