package cn.qianfg.service;

import cn.qianfg.pojo.News;
import org.springframework.web.multipart.MultipartFile;

public interface FileUploadNews {
    public News upload(News news, MultipartFile picUrl);
}
