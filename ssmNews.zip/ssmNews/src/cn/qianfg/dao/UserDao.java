package cn.qianfg.dao;

import cn.qianfg.pojo.User;

public interface UserDao {
    public User login(User user);

    public int register(User user);
}
