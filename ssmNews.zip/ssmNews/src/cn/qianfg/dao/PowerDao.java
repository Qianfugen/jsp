package cn.qianfg.dao;

public interface PowerDao {
}
