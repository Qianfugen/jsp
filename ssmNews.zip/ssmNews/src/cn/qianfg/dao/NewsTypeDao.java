package cn.qianfg.dao;

import cn.qianfg.pojo.NewsType;

import java.util.List;

public interface NewsTypeDao {
    public List<NewsType> queryAllNewsType();
}
