package cn.qianfg.dao;

public interface RoleDao {
}
